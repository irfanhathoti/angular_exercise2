import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-meterial-ui',
  templateUrl: './meterial-ui.component.html',
  styleUrls: ['./meterial-ui.component.css']
})
export class MeterialUiComponent {
  showFiller = false;

  constructor(){

  }
 

  

 

}

